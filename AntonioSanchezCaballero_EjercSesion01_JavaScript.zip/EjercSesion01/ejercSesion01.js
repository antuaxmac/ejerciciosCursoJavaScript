


console.log ("Estoy realizando el curso de JavaScript, espero aprender mucho");


